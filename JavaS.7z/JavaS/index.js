


let name = 'Yves';
let firstName = 'Mahama';
let firstName1 = 'Iragi';
let firstName2 ='Maradona';
let age = 40;
let number = 21;
let number1 =34;
let number2 =54;
let number3 =45;

console.log(name);
console.log(age);
console.log(firstName);
console.log(firstName1);
console.log(firstName2);
console.log(number);
console.log(number1);
console.log(number2);
console.log(number3);

console.log(number1 + number);
console.log(number1 / number);
console.log(number1 * number);
console.log(number1 - number);
console.log(number3 + number);


let person = {
    name: 'Kawangware',
    name1: 'Nairobi',
    name2: 'Githurai',
    name3: 'Kawangware',
    name4: 'Nairobi',
    name5: 'Githurai',
    name6: 'Kawangware',
    name7: 'Nairobi',
    name8: 'Githurai',
};
console.log(person);



// let 

let firstName33 = "mahammaa";
let lastname22 = "Epolete";
console.log(firstName33 + lastname22);