// performing a task

function greet (name, lastName) {
    console.log('Hello ' + name + ' ' + lastName);
}

//
function square(number) {
    return number * number;
}

let number = square(2);
console.log(number);


//

let number1 = 2;
let number2 = 3;
console.log(number1 * number2);
console.log(number1 / number2);
console.log(number1 + number2);
console.log(number1 - number2);
